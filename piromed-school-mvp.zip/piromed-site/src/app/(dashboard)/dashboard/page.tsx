export default function DashboardPage() {
  return (
    <div>
      <h1 className="font-display text-2xl font-bold text-brand-dark mb-2">
        Добро пожаловать в PiroMed
      </h1>
      <p className="text-brand-gray mb-8">
        Здесь будет сводка по твоим курсам и прогрессу.
      </p>

      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
        <div className="card p-5">
          <p className="text-sm text-brand-gray mb-1">Купленные курсы</p>
          <p className="text-2xl font-bold text-brand-dark">0</p>
        </div>
        <div className="card p-5">
          <p className="text-sm text-brand-gray mb-1">Сдано ДЗ</p>
          <p className="text-2xl font-bold text-brand-dark">0</p>
        </div>
        <div className="card p-5">
          <p className="text-sm text-brand-gray mb-1">Не сдано ДЗ</p>
          <p className="text-2xl font-bold text-brand-dark">0</p>
        </div>
      </div>
    </div>
  );
}
