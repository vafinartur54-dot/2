"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import {
  User,
  BookOpen,
  MessageCircle,
  Settings,
  Calendar,
  LayoutDashboard,
  Shield,
  LogOut,
} from "lucide-react";
import { cn } from "@/lib/utils";

const studentLinks = [
  { href: "/dashboard", label: "Главная", icon: LayoutDashboard },
  { href: "/profile", label: "Профиль", icon: User },
  { href: "/my-courses", label: "Мои курсы", icon: BookOpen },
  { href: "/calendar", label: "Календарь", icon: Calendar },
  { href: "/support", label: "Поддержка", icon: MessageCircle },
  { href: "/settings", label: "Настройки", icon: Settings },
];

// Mock: in real app this comes from auth
const currentUser = {
  name: "Владелец",
  role: "owner", // owner | admin | teacher | curator | moderator | student
  login: "OwnerAdm",
};

export default function DashboardLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const pathname = usePathname();
  const isAdmin = ["owner", "admin"].includes(currentUser.role);

  return (
    <div className="min-h-[calc(100vh-4rem)] flex">
      {/* Sidebar */}
      <aside className="w-60 border-r border-brand-dark/5 bg-white shrink-0 hidden md:block">
        <div className="p-5 border-b border-brand-dark/5">
          <p className="font-semibold text-brand-dark text-sm">{currentUser.name}</p>
          <p className="text-xs text-brand-gray mt-0.5 capitalize">
            {currentUser.role === "owner" ? "Владелец" : currentUser.role}
          </p>
        </div>

        <nav className="p-3 space-y-0.5">
          {studentLinks.map((link) => {
            const Icon = link.icon;
            const active = pathname === link.href;
            return (
              <Link
                key={link.href}
                href={link.href}
                className={cn(
                  "flex items-center gap-2.5 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors",
                  active
                    ? "bg-brand-cyan/10 text-brand-cyan"
                    : "text-brand-gray hover:bg-brand-dark/5 hover:text-brand-dark"
                )}
              >
                <Icon className="w-4 h-4" />
                {link.label}
              </Link>
            );
          })}

          {isAdmin && (
            <>
              <div className="my-3 border-t border-brand-dark/5" />
              <Link
                href="/admin"
                className={cn(
                  "flex items-center gap-2.5 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors",
                  pathname.startsWith("/admin")
                    ? "bg-brand-cyan/10 text-brand-cyan"
                    : "text-brand-gray hover:bg-brand-dark/5 hover:text-brand-dark"
                )}
              >
                <Shield className="w-4 h-4" />
                Админ-панель
              </Link>
            </>
          )}
        </nav>

        <div className="absolute bottom-0 w-60 p-3 border-t border-brand-dark/5">
          <button className="flex items-center gap-2.5 px-3 py-2.5 rounded-lg text-sm font-medium text-brand-gray hover:bg-red-50 hover:text-red-600 w-full transition-colors">
            <LogOut className="w-4 h-4" />
            Выйти
          </button>
        </div>
      </aside>

      {/* Content */}
      <div className="flex-1 overflow-auto">
        <div className="p-6 md:p-8">{children}</div>
      </div>
    </div>
  );
}
