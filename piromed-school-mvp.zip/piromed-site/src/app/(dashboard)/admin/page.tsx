"use client";

import { useState } from "react";
import { Users, BookOpen, DollarSign, MessageSquare } from "lucide-react";

const initialPrices = {
  chem: 3990,
  bio: 3990,
  combo: 6990,
};

export default function AdminPage() {
  const [prices, setPrices] = useState(initialPrices);
  const [editing, setEditing] = useState<string | null>(null);
  const [tempPrice, setTempPrice] = useState("");

  const startEdit = (key: string, value: number) => {
    setEditing(key);
    setTempPrice(String(value));
  };

  const savePrice = (key: string) => {
    const num = parseInt(tempPrice, 10);
    if (!isNaN(num) && num > 0) {
      setPrices((prev) => ({ ...prev, [key]: num }));
    }
    setEditing(null);
  };

  return (
    <div>
      <h1 className="font-display text-2xl font-bold text-brand-dark mb-2">
        Админ-панель
      </h1>
      <p className="text-brand-gray mb-8">
        Управление пользователями, курсами, ценами и поддержкой
      </p>

      <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-10">
        {[
          { label: "Пользователи", icon: Users, href: "/admin/users" },
          { label: "Курсы", icon: BookOpen, href: "/admin/courses" },
          { label: "Цены", icon: DollarSign, href: "#prices" },
          { label: "Поддержка", icon: MessageSquare, href: "/admin/support" },
        ].map((item) => (
          <a
            key={item.label}
            href={item.href}
            className="card p-5 flex items-center gap-3 hover:border-brand-cyan/30"
          >
            <item.icon className="w-5 h-5 text-brand-cyan" />
            <span className="font-medium text-brand-dark">{item.label}</span>
          </a>
        ))}
      </div>

      {/* Prices editor */}
      <section id="prices" className="card p-6">
        <h2 className="font-display text-lg font-bold text-brand-dark mb-4">
          Редактирование цен курсов
        </h2>
        <div className="space-y-4">
          {[
            { key: "chem", label: "Химия" },
            { key: "bio", label: "Биология" },
            { key: "combo", label: "Химия + Биология" },
          ].map((item) => (
            <div
              key={item.key}
              className="flex items-center justify-between py-3 border-b border-brand-dark/5 last:border-0"
            >
              <span className="font-medium text-brand-dark">{item.label}</span>
              {editing === item.key ? (
                <div className="flex items-center gap-2">
                  <input
                    type="number"
                    value={tempPrice}
                    onChange={(e) => setTempPrice(e.target.value)}
                    className="w-28 px-3 py-1.5 border border-brand-dark/15 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-brand-cyan/30"
                    autoFocus
                  />
                  <span className="text-sm text-brand-gray">₽ / мес</span>
                  <button
                    onClick={() => savePrice(item.key)}
                    className="text-sm font-semibold text-brand-cyan hover:underline"
                  >
                    Сохранить
                  </button>
                  <button
                    onClick={() => setEditing(null)}
                    className="text-sm text-brand-gray hover:underline"
                  >
                    Отмена
                  </button>
                </div>
              ) : (
                <div className="flex items-center gap-3">
                  <span className="font-bold text-brand-dark">
                    {prices[item.key as keyof typeof prices]} ₽ / мес
                  </span>
                  <button
                    onClick={() =>
                      startEdit(item.key, prices[item.key as keyof typeof prices])
                    }
                    className="text-sm font-semibold text-brand-cyan hover:underline"
                  >
                    Изменить
                  </button>
                </div>
              )}
            </div>
          ))}
        </div>
        <p className="text-xs text-brand-gray mt-4">
          Изменения сохраняются локально (в MVP). Позже подключим базу данных.
        </p>
      </section>
    </div>
  );
}
