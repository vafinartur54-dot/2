import Link from "next/link";
import { Check } from "lucide-react";

const plans = [
  {
    id: "chem",
    title: "Химия",
    price: "3 990",
    features: [
      "Живые занятия",
      "Конспекты и материалы",
      "Домашние задания",
      "Проверка работ",
      "Разбор ошибок",
      "Поддержка преподавателя",
    ],
  },
  {
    id: "bio",
    title: "Биология",
    price: "3 990",
    features: [
      "Живые занятия",
      "Конспекты и материалы",
      "Домашние задания",
      "Проверка работ",
      "Разбор ошибок",
      "Поддержка преподавателя",
    ],
  },
  {
    id: "combo",
    title: "Химия + Биология",
    price: "6 990",
    popular: true,
    features: [
      "Всё из курсов Химия и Биология",
      "Единый личный кабинет",
      "Приоритетная поддержка",
      "Дополнительные материалы",
      "Контроль прогресса по двум предметам",
    ],
  },
];

export default function PricingPage() {
  return (
    <div className="py-12 md:py-16">
      <div className="container-main">
        <div className="text-center max-w-2xl mx-auto mb-12">
          <h1 className="font-display text-3xl md:text-4xl font-bold text-brand-dark mb-4">
            Выбери свой путь
          </h1>
          <p className="text-brand-gray text-lg">
            Можно начать с бесплатных уроков. Цены можно будет изменить в админке.
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-6 max-w-5xl mx-auto">
          {plans.map((plan) => (
            <div
              key={plan.id}
              className={`card p-6 md:p-8 relative ${
                plan.popular ? "ring-2 ring-brand-cyan" : ""
              }`}
            >
              {plan.popular && (
                <span className="absolute -top-3 left-1/2 -translate-x-1/2 bg-brand-cyan text-white text-xs font-semibold px-3 py-1 rounded-full">
                  Выгодно
                </span>
              )}
              <h2 className="font-display text-xl font-bold text-brand-dark mb-1">
                {plan.title}
              </h2>
              <p className="text-3xl font-bold text-brand-dark mb-6">
                {plan.price} ₽
                <span className="text-base font-normal text-brand-gray"> / мес</span>
              </p>
              <ul className="space-y-3 mb-8">
                {plan.features.map((f) => (
                  <li key={f} className="flex items-start gap-2.5 text-sm text-brand-gray">
                    <Check className="w-4 h-4 text-brand-cyan shrink-0 mt-0.5" />
                    {f}
                  </li>
                ))}
              </ul>
              <Link
                href="/courses"
                className={`w-full text-center ${
                  plan.popular ? "btn-primary" : "btn-secondary"
                }`}
              >
                Смотреть бесплатные уроки
              </Link>
            </div>
          ))}
        </div>

        <p className="text-center text-sm text-brand-gray mt-10">
          Цены редактируются владельцем и админами в панели управления.
        </p>
      </div>
    </div>
  );
}
