import Link from "next/link";
import { FlaskConical, Dna, PlayCircle, Lock } from "lucide-react";

const courses = [
  {
    id: "chem",
    title: "Химия",
    description: "От базовых понятий до сложных задач и подготовки к ЕГЭ",
    price: "3 990 ₽ / мес",
    freeLessons: 3,
    icon: FlaskConical,
    color: "bg-blue-50 text-blue-600",
  },
  {
    id: "bio",
    title: "Биология",
    description: "От клеточного уровня до генетики, анатомии и ЕГЭ",
    price: "3 990 ₽ / мес",
    freeLessons: 3,
    icon: Dna,
    color: "bg-teal-50 text-teal-600",
  },
  {
    id: "chem-bio",
    title: "Химия + Биология",
    description: "Полный комплект для поступления в медицинский вуз",
    price: "6 990 ₽ / мес",
    freeLessons: 6,
    icon: FlaskConical,
    color: "bg-indigo-50 text-indigo-600",
  },
];

export default function CoursesPage() {
  return (
    <div className="py-12 md:py-16">
      <div className="container-main">
        <div className="max-w-2xl mb-12">
          <h1 className="font-display text-3xl md:text-4xl font-bold text-brand-dark mb-4">
            Курсы PiroMed School
          </h1>
          <p className="text-brand-gray text-lg">
            Посмотри бесплатные уроки и реши, подходит ли тебе наш подход.
            После этого можно получить полный доступ.
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-6">
          {courses.map((course) => {
            const Icon = course.icon;
            return (
              <div key={course.id} className="card overflow-hidden flex flex-col">
                <div className="p-6 flex-1">
                  <div
                    className={`w-12 h-12 rounded-xl ${course.color} flex items-center justify-center mb-4`}
                  >
                    <Icon className="w-6 h-6" />
                  </div>
                  <h2 className="font-display text-xl font-bold text-brand-dark mb-2">
                    {course.title}
                  </h2>
                  <p className="text-brand-gray text-sm mb-4 leading-relaxed">
                    {course.description}
                  </p>
                  <p className="text-lg font-bold text-brand-dark mb-1">
                    {course.price}
                  </p>
                  <p className="text-sm text-brand-cyan font-medium mb-5">
                    {course.freeLessons} бесплатных урока
                  </p>
                </div>
                <div className="px-6 pb-6 flex flex-col gap-2">
                  <Link
                    href={`/courses/${course.id}`}
                    className="btn-primary text-center text-sm"
                  >
                    <PlayCircle className="w-4 h-4 mr-2" />
                    Смотреть бесплатные уроки
                  </Link>
                  <button className="btn-secondary text-sm w-full">
                    Получить полный доступ
                  </button>
                </div>
              </div>
            );
          })}
        </div>

        <div className="mt-12 p-6 rounded-card bg-brand-cyan-pale/50 border border-brand-cyan/20">
          <h3 className="font-display font-bold text-brand-dark mb-2">
            Как получить доступ к курсу?
          </h3>
          <p className="text-brand-gray text-sm leading-relaxed">
            После оплаты (или договорённости) администратор выдаёт тебе статус
            «Ученик» и нужный курс в личном кабинете. Пока платёжная система в
            разработке — напиши в поддержку, и мы всё оформим вручную.
          </p>
        </div>
      </div>
    </div>
  );
}
