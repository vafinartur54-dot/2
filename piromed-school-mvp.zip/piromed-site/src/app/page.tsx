import Link from "next/link";
import { ArrowRight, BookOpen, FlaskConical, Dna, GraduationCap, CheckCircle2 } from "lucide-react";

export default function HomePage() {
  return (
    <>
      {/* Hero */}
      <section className="relative overflow-hidden bg-gradient-to-b from-brand-cyan-pale/40 to-white">
        <div className="container-main py-16 md:py-24 lg:py-28">
          <div className="max-w-3xl">
            <p className="text-sm font-semibold tracking-widest text-brand-cyan uppercase mb-4">
              PiroMed School
            </p>
            <h1 className="font-display text-4xl sm:text-5xl lg:text-6xl font-extrabold text-brand-dark leading-[1.15] mb-6">
              Химия и биология,
              <br />
              которые ведут в медицину
            </h1>
            <p className="text-lg text-brand-gray max-w-xl mb-8 leading-relaxed">
              Онлайн-занятия от студентов Пироговского университета для школьников,
              которые хотят поступить в медицинский вуз.
            </p>
            <div className="flex flex-wrap gap-3">
              <Link href="/courses" className="btn-primary">
                Смотреть бесплатные уроки
                <ArrowRight className="ml-2 w-4 h-4" />
              </Link>
              <Link href="/pricing" className="btn-secondary">
                Посмотреть программы
              </Link>
            </div>
            <p className="mt-6 text-sm text-brand-gray/80 tracking-wide">
              ХИМИЯ • БИОЛОГИЯ • ЕГЭ • ПОСТУПЛЕНИЕ В МЕД
            </p>
          </div>
        </div>
      </section>

      {/* Social proof */}
      <section className="border-y border-brand-dark/5 bg-white">
        <div className="container-main py-5 flex flex-wrap items-center justify-center gap-6 md:gap-10 text-sm text-brand-gray">
          <span className="font-medium text-brand-dark">
            Создано студентами-медиками для будущих студентов-медиков
          </span>
          <span className="flex items-center gap-1.5">
            <Dna className="w-4 h-4 text-brand-cyan" /> Биология
          </span>
          <span className="flex items-center gap-1.5">
            <FlaskConical className="w-4 h-4 text-brand-cyan" /> Химия
          </span>
          <span className="flex items-center gap-1.5">
            <GraduationCap className="w-4 h-4 text-brand-cyan" /> ЕГЭ
          </span>
        </div>
      </section>

      {/* Why PiroMed */}
      <section className="py-16 md:py-24">
        <div className="container-main">
          <div className="max-w-2xl mb-12">
            <h2 className="font-display text-3xl md:text-4xl font-bold text-brand-dark mb-4">
              Мы сами недавно были на твоём месте
            </h2>
            <p className="text-brand-gray text-lg">
              Поэтому понимаем не только предмет, но и сам путь до медицинского университета.
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-6">
            {[
              {
                num: "01",
                title: "Студенты-медики",
                text: "Наши преподаватели сами прошли путь подготовки и поступления в медицинский вуз.",
              },
              {
                num: "02",
                title: "Понимание, а не зубрёжка",
                text: "Разбираемся в логике химии и биологии, чтобы знания действительно оставались в голове.",
              },
              {
                num: "03",
                title: "Цель — медицина",
                text: "Выстраиваем обучение с учётом цели будущего абитуриента.",
              },
            ].map((item) => (
              <div key={item.num} className="card p-6 md:p-8">
                <span className="text-brand-cyan font-display font-bold text-sm tracking-wider">
                  {item.num}
                </span>
                <h3 className="font-display text-xl font-bold text-brand-dark mt-3 mb-2">
                  {item.title}
                </h3>
                <p className="text-brand-gray leading-relaxed">{item.text}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Subjects */}
      <section className="py-16 md:py-24 bg-brand-cyan-pale/30">
        <div className="container-main">
          <h2 className="font-display text-3xl md:text-4xl font-bold text-brand-dark mb-10 text-center">
            Выбери направление
          </h2>

          <div className="grid md:grid-cols-2 gap-6 max-w-4xl mx-auto">
            <Link href="/chemistry" className="card p-8 group">
              <div className="w-12 h-12 rounded-xl bg-brand-cyan/10 flex items-center justify-center mb-5">
                <FlaskConical className="w-6 h-6 text-brand-cyan" />
              </div>
              <h3 className="font-display text-2xl font-bold text-brand-dark mb-2 group-hover:text-brand-cyan transition-colors">
                Химия
              </h3>
              <p className="text-brand-gray mb-5">
                От базовых понятий до сложных задач и подготовки к ЕГЭ.
              </p>
              <ul className="space-y-1.5 text-sm text-brand-gray mb-6">
                <li>Общая химия</li>
                <li>Неорганика</li>
                <li>Органика</li>
                <li>Задачи и ЕГЭ</li>
              </ul>
              <span className="inline-flex items-center text-sm font-semibold text-brand-cyan">
                Подробнее <ArrowRight className="ml-1.5 w-4 h-4" />
              </span>
            </Link>

            <Link href="/biology" className="card p-8 group">
              <div className="w-12 h-12 rounded-xl bg-brand-cyan/10 flex items-center justify-center mb-5">
                <Dna className="w-6 h-6 text-brand-cyan" />
              </div>
              <h3 className="font-display text-2xl font-bold text-brand-dark mb-2 group-hover:text-brand-cyan transition-colors">
                Биология
              </h3>
              <p className="text-brand-gray mb-5">
                От клеточного уровня до генетики, анатомии и ЕГЭ.
              </p>
              <ul className="space-y-1.5 text-sm text-brand-gray mb-6">
                <li>Цитология</li>
                <li>Генетика</li>
                <li>Анатомия</li>
                <li>Молекулярная биология и ЕГЭ</li>
              </ul>
              <span className="inline-flex items-center text-sm font-semibold text-brand-cyan">
                Подробнее <ArrowRight className="ml-1.5 w-4 h-4" />
              </span>
            </Link>
          </div>
        </div>
      </section>

      {/* What you get */}
      <section className="py-16 md:py-24">
        <div className="container-main">
          <h2 className="font-display text-3xl md:text-4xl font-bold text-brand-dark mb-10 text-center">
            Что получает ученик
          </h2>
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-5 max-w-5xl mx-auto">
            {[
              "Живые занятия",
              "Конспекты",
              "Домашние задания",
              "Проверка работ",
              "Разбор ошибок",
              "Тестирование",
              "Поддержка преподавателя",
              "Контроль прогресса",
            ].map((item) => (
              <div
                key={item}
                className="flex items-center gap-3 p-4 rounded-xl bg-brand-cyan-pale/50"
              >
                <CheckCircle2 className="w-5 h-5 text-brand-cyan shrink-0" />
                <span className="text-sm font-medium text-brand-dark">{item}</span>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Pricing teaser */}
      <section className="py-16 md:py-24 bg-brand-dark text-white">
        <div className="container-main text-center">
          <h2 className="font-display text-3xl md:text-4xl font-bold mb-4">
            Выбери свой формат
          </h2>
          <p className="text-white/60 mb-10 max-w-lg mx-auto">
            Можно начать с бесплатных уроков и потом выбрать подходящий курс
          </p>

          <div className="grid md:grid-cols-3 gap-6 max-w-4xl mx-auto">
            {[
              { title: "Химия", price: "3 990 ₽", period: "/ месяц" },
              { title: "Биология", price: "3 990 ₽", period: "/ месяц" },
              { title: "Химия + Биология", price: "6 990 ₽", period: "/ месяц" },
            ].map((plan) => (
              <div
                key={plan.title}
                className="rounded-card bg-white/5 border border-white/10 p-6 text-left"
              >
                <h3 className="font-display font-bold text-lg mb-1">{plan.title}</h3>
                <p className="text-3xl font-bold text-brand-cyan-light mb-4">
                  {plan.price}
                  <span className="text-base font-normal text-white/50">{plan.period}</span>
                </p>
                <Link
                  href="/pricing"
                  className="inline-flex text-sm font-semibold text-brand-cyan-light hover:underline"
                >
                  Подробнее →
                </Link>
              </div>
            ))}
          </div>

          <div className="mt-10">
            <Link
              href="/courses"
              className="btn-primary bg-brand-cyan hover:bg-[#00b8a9]"
            >
              Смотреть бесплатные уроки
            </Link>
          </div>
        </div>
      </section>

      {/* Final CTA */}
      <section className="py-16 md:py-24">
        <div className="container-main text-center">
          <h2 className="font-display text-3xl md:text-4xl font-bold text-brand-dark mb-4">
            Твой путь в медицину начинается здесь
          </h2>
          <p className="text-brand-gray text-lg mb-8 max-w-md mx-auto">
            Начни с бесплатных уроков. Дальше — больше.
          </p>
          <Link href="/courses" className="btn-primary">
            Начать бесплатно
            <ArrowRight className="ml-2 w-4 h-4" />
          </Link>
        </div>
      </section>
    </>
  );
}
