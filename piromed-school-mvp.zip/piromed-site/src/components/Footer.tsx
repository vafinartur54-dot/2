import Link from "next/link";
import Image from "next/image";

export function Footer() {
  return (
    <footer className="bg-brand-dark text-white">
      <div className="container-main py-12 md:py-16">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-10">
          {/* Brand */}
          <div className="md:col-span-1">
            <Image
              src="/logo-dark.png"
              alt="PiroMed School"
              width={140}
              height={40}
              className="h-9 w-auto mb-4 brightness-0 invert"
            />
            <p className="text-sm text-white/60 leading-relaxed">
              Химия • Биология • Поступление в мед
            </p>
            <p className="mt-3 text-sm text-white/50">
              От студентов-медиков — будущим студентам-медикам
            </p>
          </div>

          {/* Links */}
          <div>
            <h4 className="font-semibold text-sm mb-4">Школа</h4>
            <ul className="space-y-2.5 text-sm text-white/60">
              <li>
                <Link href="/about" className="hover:text-white transition-colors">
                  О школе
                </Link>
              </li>
              <li>
                <Link href="/teachers" className="hover:text-white transition-colors">
                  Преподаватели
                </Link>
              </li>
              <li>
                <Link href="/chemistry" className="hover:text-white transition-colors">
                  Химия
                </Link>
              </li>
              <li>
                <Link href="/biology" className="hover:text-white transition-colors">
                  Биология
                </Link>
              </li>
              <li>
                <Link href="/pricing" className="hover:text-white transition-colors">
                  Цены
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <h4 className="font-semibold text-sm mb-4">Помощь</h4>
            <ul className="space-y-2.5 text-sm text-white/60">
              <li>
                <Link href="/faq" className="hover:text-white transition-colors">
                  FAQ
                </Link>
              </li>
              <li>
                <Link href="/contacts" className="hover:text-white transition-colors">
                  Контакты
                </Link>
              </li>
              <li>
                <a
                  href="https://t.me/PiromedHelp"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="hover:text-white transition-colors"
                >
                  Telegram поддержки
                </a>
              </li>
            </ul>
          </div>

          <div>
            <h4 className="font-semibold text-sm mb-4">Документы</h4>
            <ul className="space-y-2.5 text-sm text-white/60">
              <li>
                <Link href="/privacy" className="hover:text-white transition-colors">
                  Политика конфиденциальности
                </Link>
              </li>
              <li>
                <Link href="/offer" className="hover:text-white transition-colors">
                  Публичная оферта
                </Link>
              </li>
            </ul>
          </div>
        </div>

        <div className="mt-12 pt-6 border-t border-white/10 flex flex-col sm:flex-row justify-between items-center gap-4 text-xs text-white/40">
          <p>© {new Date().getFullYear()} PiroMed School. Все права защищены.</p>
          <p>Не является официальным проектом Пироговского университета</p>
        </div>
      </div>
    </footer>
  );
}
