"use client";

import Link from "next/link";
import Image from "next/image";
import { useState } from "react";
import { Menu, X } from "lucide-react";

const navLinks = [
  { href: "/about", label: "О школе" },
  { href: "/teachers", label: "Преподаватели" },
  { href: "/chemistry", label: "Химия" },
  { href: "/biology", label: "Биология" },
  { href: "/pricing", label: "Цены" },
  { href: "/faq", label: "FAQ" },
];

export function Header() {
  const [mobileOpen, setMobileOpen] = useState(false);

  return (
    <header className="sticky top-0 z-50 bg-white/90 backdrop-blur-md border-b border-brand-dark/5">
      <div className="container-main">
        <div className="flex items-center justify-between h-16 md:h-18">
          {/* Logo */}
          <Link href="/" className="flex items-center gap-2 shrink-0">
            <Image
              src="/logo-light.png"
              alt="PiroMed School"
              width={140}
              height={40}
              className="h-9 w-auto"
              priority
            />
          </Link>

          {/* Desktop Nav */}
          <nav className="hidden lg:flex items-center gap-7">
            {navLinks.map((link) => (
              <Link
                key={link.href}
                href={link.href}
                className="text-sm font-medium text-brand-gray hover:text-brand-dark transition-colors"
              >
                {link.label}
              </Link>
            ))}
          </nav>

          {/* CTA + Auth */}
          <div className="hidden lg:flex items-center gap-3">
            <Link
              href="/login"
              className="text-sm font-medium text-brand-gray hover:text-brand-dark transition-colors"
            >
              Войти
            </Link>
            <Link href="/courses" className="btn-primary text-sm py-2.5 px-5">
              Смотреть курсы
            </Link>
          </div>

          {/* Mobile menu button */}
          <button
            className="lg:hidden p-2 text-brand-dark"
            onClick={() => setMobileOpen(!mobileOpen)}
            aria-label="Меню"
          >
            {mobileOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>
      </div>

      {/* Mobile menu */}
      {mobileOpen && (
        <div className="lg:hidden border-t border-brand-dark/5 bg-white">
          <div className="container-main py-4 space-y-1">
            {navLinks.map((link) => (
              <Link
                key={link.href}
                href={link.href}
                className="block py-2.5 text-sm font-medium text-brand-dark"
                onClick={() => setMobileOpen(false)}
              >
                {link.label}
              </Link>
            ))}
            <div className="pt-3 flex flex-col gap-2">
              <Link
                href="/login"
                className="btn-secondary text-center"
                onClick={() => setMobileOpen(false)}
              >
                Войти
              </Link>
              <Link
                href="/courses"
                className="btn-primary text-center"
                onClick={() => setMobileOpen(false)}
              >
                Смотреть курсы
              </Link>
            </div>
          </div>
        </div>
      )}
    </header>
  );
}
