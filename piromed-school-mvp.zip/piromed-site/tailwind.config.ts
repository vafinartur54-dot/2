import type { Config } from "tailwindcss";

const config: Config = {
  content: [
    "./src/pages/**/*.{js,ts,jsx,tsx,mdx}",
    "./src/components/**/*.{js,ts,jsx,tsx,mdx}",
    "./src/app/**/*.{js,ts,jsx,tsx,mdx}",
  ],
  darkMode: "class",
  theme: {
    extend: {
      colors: {
        brand: {
          dark: "#0B2A4A",
          navy: "#0D2942",
          blue: "#1769FF",
          cyan: "#00D1C1",
          "cyan-light": "#7FE6D9",
          "cyan-pale": "#EAF3FF",
          gray: "#667585",
          white: "#FFFFFF",
        },
      },
      fontFamily: {
        sans: ["Inter", "system-ui", "sans-serif"],
        display: ["Montserrat", "system-ui", "sans-serif"],
      },
      borderRadius: {
        card: "1.25rem",
        btn: "0.875rem",
      },
      boxShadow: {
        soft: "0 4px 20px -2px rgba(11, 42, 74, 0.08)",
        "soft-lg": "0 10px 40px -5px rgba(11, 42, 74, 0.12)",
      },
    },
  },
  plugins: [],
};

export default config;
